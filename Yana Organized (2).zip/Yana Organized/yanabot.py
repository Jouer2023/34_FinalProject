import openai
import os 

from openai import OpenAI #Importing OpenAI class from openai library


#Initializing the OpenAI client with the API key
client = OpenAI(
    api_key = "your openai api key"
); #I must be the client 


#Get completion Function
def get_completion(prompt, model="gpt-3.5-turbo", temperature=0):  #Takes prompt as input
    messages = [{"role": "user", "content": prompt}] #Dictionary to store message history

    response =  client.chat.completions.create( #Method to create chat completion (to generate text based on the prompt)
        model= model,
        messages=messages,
        temperature=temperature,
    )
    return response.choices[0].message.content  #Returns the first choice of the content in the response


# helper function that takes a list of messages
def get_completion_from_messages(messages, model="gpt-3.5-turbo", temperature=0.3):
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature, # this is the degree of randomness of the model's output
    )
#     print(str(response.choices[0].message))
    return response.choices[0].message.content


# Function to interact with the GPT-3.5 model for testing and carrying out conversations with Yana bot
def chat_with_bot(messages):
    # Gets the user's message
    user_message = messages[-1]["content"]       #Last from the message list

    # Gets the category of the response using a separate function
    response_category = get_response_category(user_message)     #Uses the user's message to categorize

    # Appends the category to the system message as an assistant (the bot)
    messages.append({"role": "assistant", "content": response_category})

    # Makes a request to the OpenAI Chat API to generate Yana's response 
    response = get_completion_from_messages(messages)    #Updated messages list
    response = response.replace('. ', '.\n') #Replace function that takes the old string and new string as parameters

    # Extracts and returns the assistant's response from the API response
    return response


# Function to get the category of the response using the GPT-3.5 model
def get_response_category(user_message): #user_message as input

    # Defines the categories offered by the chatbot using a dictionary
    categories_dict = {
     #Features Yana offers   
        "Empathetic and understanding responses": {
            "keywords": ["empathy", "understanding"],
            "action": "Provide empathetic and supportive responses.",
        },
     
        "Active listening": {
            "keywords": ["listening", "engagement"],
            "action": "Actively listen to the user's concerns and engage in the conversation.",
        },
     
        "Resource provision": {
            "keywords": ["resources", "information"],
            "action": "Offer relevant resources and information to assist the user.",
        },
     
        "Daily positive affirmations": {
            "keywords": ["affirmations", "positivity"],
            "action": "Share daily positive affirmations to uplift the user's mood.",
        },
     
        "Self-care": {
            "keywords": ["relaxation", "self-care"],
            "action": "Share some self-care activities a person can perform.",
        },
     
        "Mindfulness": {
            "keywords": ["mindfulness", "meditation", "peace"],
            "action": "Share the benefits and some techniques that can be practiced.",
        },
     
        "Coping skills": {
            "keywords": ["stress", "coping"],
            "action": "Share with the user some coping skills to overcome stress or other harsh emotions.",
        },
     
        "Journaling": {
            "keywords": ["reflect", "record", "writing", "escape"],
            "action": "Share with the user how to practice journaling.",
        },
     
        "Constant improvement": {
            "keywords": ["improvement", "feedback"],
            "action": "Seek feedback for constant improvement and better user experience.",
        },
        "Off topic": {
            "keywords": ["off topic", "random"],
            "action": "Handle off-topic questions gracefully and guide the user back to the main topics.",
        }
    }


    # Constructs a prompt that includes the categories and actions
    category_prompt = f"""Predict the category for the following user \
    message: '{user_message}'\nCategories: {', '.join(categories_dict.keys())}\nCategory:\ #adds the category names
    return the category in the format, category:action"""
    category_response = get_completion(category_prompt)  #Generating a completion for the category

    # Extract the predicted category from the model response
    return category_response


# Function to start the chat application
def start_chat():
    # Prints a welcome message
    print("Yana: Hello, what's up? I'm Yana, your custom chatbot here to support you.")

    # Initialize the conversation (messages list) with a system message
    messages = [
        {"role": "system", "content": "You are a friendly and helpful assistant that is ready to talk about mental health."},
    ]

    # Condition to carry on with the message until the user says bye
    while True:
        # Get user input
        user_input = input("You: ")

        # Checks if the user wants to end the conversation
        if user_input.lower() == 'bye':
            print("Yana: Goodbye! Take care.")
            break

        # Appends the user's message to the conversation
        messages.append({"role": "user", "content": user_input})

        # Provides a response for the user and prints it out
        bot_response = chat_with_bot(messages)
        print("Yana:", bot_response)

        # Appends the assistant's message to the conversation
        messages.append({"role": "assistant", "content": bot_response})

   

start_chat()
