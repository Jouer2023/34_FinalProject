# -Yana Final Project 
Yana is a text-based AI assistant designed to provide support and assistance through interactive conversations.

## Yana
To use Yana, access this [website]([https://34finalproject-7yrbkda2rx8tpocwzw9qy8.streamlit.app/])!

## Problem 
Demonstrating an artefact in the field of Artificial Intelligence, mainly a deep learning project.

### Dataset
No dataset was used directly as the gpt 3.5 turbo model was used here.

### Files
There are files for User Interface, flask server and a regular python file which can be implemented in any IDE.

### Features
* Coversational chatbot: Engage in conversations with Yana by providing user input.
* GPT-3.5-turbo Model: Utilizes OpenAI's GPT-3.5-turbo for natural language processing.

## Usage
#### Clone the repository

#### Set up your own OpenAI key

#### Run the script 

#### Interact with the project 

#### Deploy on any cloud server or interface you are comfortable with

## Deployment using flask and heroku and also streamlit
* Install flask: pip install flask
* Create a flask application file: file-with .py extension
* Import flask and instantiate it: from flask import Flask
* app = Flask(__name__)
* Define routes that correspond to specific urls: @app.route("/")
* Run it : python filename.py
* Access the file using the given link

* For Heroku, sign up for an account
* Install the Command line interface from the site.
* Login into Heroku
* Create a new application
* Set up a git repo and add your files to it
* Then deploy

### Deployment of the app using the files in the repo (Streamlit)
* [Create an account on streamlit]([https://share.streamlit.io/signup]). 
* Add your app to GitHub to deploy it.
* From your workspace at share.streamlit.io, click "New app" from the upper-right corner of your workspace.
Fill in your repo, branch, and file path. As a shortcut, you can also click "Paste GitHub URL" to paste a link directly to your_app.py on GitHub. 
* Watch your app launch and acquire your app url that you can share.
* https://[GitHub username or organization]-[repo name]-[app path]-[branch name]-[short hash].streamlit.app (Your app url will look something like this and then you are done.)







## Video Link on Usage
[Here!]([https://youtu.be/1ZTJ1tGipbI])
[or Here! or]([https://youtu.be/1ZTJ1tGipbI])
[Here!]([https://youtu.be/DlQCmoZpqQY])

### Conclusion
You can mess around and enlarge this project by adding more functionalities. You can change the user interface to fit your taste and train the bot for other purposes. 

## References
Get started - Streamlit Docs. (n.d.). https://docs.streamlit.io/streamlit-community-cloud/get-started 

https://www.geeksforgeeks.org/a-beginners-guide-to-streamlit/