 
import streamlit as st  #imports streamlit library for user interface 
from openai import OpenAI #imports the OpenAI library

#Initialization of client with API key
client = OpenAI(api_key= "api key")

#Function for completion which takes prompt for user input (Used for the categories generation)
def get_completion(prompt, model="gpt-3.5-turbo", temperature=0):
    messages = [{"role": "user", "content": prompt}]
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
    )
    return response.choices[0].message.content

#Second helper function
def get_completion_from_messages(messages, model="gpt-3.5-turbo", temperature=0):
    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=temperature,
    )
    return response.choices[0].message.content

#Chatbot function
def chat_with_bot(messages):
    # Gets the user's message
    user_message = messages[-1]["content"]

    # Gets the category of the response using a separate function
    response_category = get_response_category(user_message)

    # Appends the category to the system message
    messages.append({"role": "assistant", "content": response_category})

    # Makes a request to the OpenAI Chat API
    response = get_completion_from_messages(messages)

    # Extracts and returns the assistant's response from the API response
    return response

def get_response_category(user_message):
    # Defines the categories offered by the chatbot
    categories_dict = {
     #Features Yana offers   
        "Empathetic and understanding responses": {
            "keywords": ["empathy", "understanding"],
            "action": "Provide empathetic and supportive responses.",
        },
     
        "Active listening": {
            "keywords": ["listening", "engagement"],
            "action": "Actively listen to the user's concerns and engage in the conversation.",
        },
     
        "Resource provision": {
            "keywords": ["resources", "information"],
            "action": "Offer relevant resources and information to assist the user.",
        },
     
        "Daily positive affirmations": {
            "keywords": ["affirmations", "positivity"],
            "action": "Share daily positive affirmations to uplift the user's mood.",
        },
     
        "Self-care": {
            "keywords": ["relaxation", "self-care"],
            "action": "Share some self-care activities a person can perform.",
        },
     
        "Mindfulness": {
            "keywords": ["mindfulness", "meditation", "peace"],
            "action": "Share the benefits and some techniques that can be practiced.",
        },
     
        "Coping skills": {
            "keywords": ["stress", "coping"],
            "action": "Share with the user some coping skills to overcome stress or other harsh emotions.",
        },
     
        "Journaling": {
            "keywords": ["reflect", "record", "writing", "escape"],
            "action": "Share with the user how to practice journaling.",
        },
     
        "Constant improvement": {
            "keywords": ["improvement", "feedback"],
            "action": "Seek feedback for constant improvement and better user experience.",
        },
        "Off topic": {
            "keywords": ["off topic", "random"],
            "action": "Handle off-topic questions gracefully and guide the user back to the main topics.",
        }
    }

    # Constructs a prompt that includes the categories and actions
    category_prompt = f"""Predict the category for the following user \ 
    message: '{user_message}'\nCategories: {', '.join(categories_dict.keys())}\nCategory:\
    return the category in the format, category:action"""
    category_response = get_completion(category_prompt)

    # Extracts the predicted category from the model response    
    return category_response
  
#User interface setup
def main():
    st.title("Yana Care")  #Sets the title of the app 

    st.write("Hello! I'm Yana, your custom chatbot here to support you.") #Displays a welcome message

    # Initializes the conversation with a system message
    messages = [{"role": "system", "content": "You are a friendly and helpful assistant ready to talk about mental health."}]

    # Gets user input
    user_input = st.text_input("You:") #A field for the user to enter messages

    # Appends the user's message to the conversation
    messages.append({"role": "user", "content": user_input})

    # Provides a response for the user and displays it
    if st.button("Send"):  #Checks if user has clicked the send button
        bot_response = chat_with_bot(messages)
        st.text_area("Yana:", value=bot_response) #Displays the response of the assistant in the text box

#Calls the main function
if __name__ == "__main__":
    main()
